#![cfg(any(feature = "mlx-backend", feature = "prism-backend", feature = "prism-backend-ios"))]
//! Live IOSurface arena for ANE-TRI-LANE-REALIZATION-0001 Phase 1.
//!
//! Provides sealed arena metadata, live IOSurface arena installation, and
//! slot state machines with explicit ownership semantics.

use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// Digest type for layout verification.
#[allow(dead_code)]
type Digest = String;

/// Slot identifier.
type SlotId = u32;

/// Arena identifier.
type ArenaId = String;

/// A monotonic epoch + generation pair for slot freshness tracking.
#[allow(dead_code)]
type SlotGeneration = u64;

pub use crate::ecs::compute_image::slot_types::{SlotFailureReason, SlotState};

/// IOSurface slot manifest (immutable, from CImage).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IOSurfaceSlotManifest {
    pub slot_id: SlotId,
    pub tensor_id: String,
    pub byte_offset: u64,
    pub byte_length: u64,
    pub dtype: String,
    pub logical_shape: Vec<u32>,
    pub physical_shape: Vec<u32>,
    pub strides_bytes: Vec<u64>,
    pub layout: String,
    pub producer: ExecutionLane,
    pub consumer: ExecutionLane,
    pub reuse_class: SlotReuseClass,
    pub required_alignment: u64,
}

pub use crate::ecs::backend::placement::ExecutionLane;
pub use crate::ecs::compute_image::slot_types::SlotReuseClass;

/// Pool-level telemetry for IOSurface lifecycle diagnostics.
///
/// Recorded at allocation boundaries and on any rc=-3 failure to
/// distinguish pool exhaustion from lifecycle bugs.
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct IOSurfacePoolSnapshot {
    pub total_slots: u32,
    pub leased_slots: u32,
    pub free_slots: u32,
    pub pending_release_slots: u32,
    pub allocation_failures: u64,
    pub release_failures: u64,
    pub high_watermark: u32,
}

impl Default for IOSurfacePoolSnapshot {
    fn default() -> Self {
        Self {
            total_slots: 0,
            leased_slots: 0,
            free_slots: 0,
            pending_release_slots: 0,
            allocation_failures: 0,
            release_failures: 0,
            high_watermark: 0,
        }
    }
}

/// Attestation of a real IOSurface allocation against its manifest.
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct IOSurfaceAllocationAttestation {
    pub slot_id: u32,
    pub iosurface_id: u32,
    pub actual_width: u32,
    pub actual_height: u32,
    pub actual_bytes_per_row: u32,
    pub actual_pixel_format: u32,
    pub actual_byte_capacity: u64,
    pub manifest_layout_digest: String,
    pub attested: bool,
}

/// Live IOSurface slot at runtime.
pub struct LiveIOSurfaceSlot {
    pub manifest: IOSurfaceSlotManifest,
    pub state: SlotState,
    pub generation: u64,
    pub layout_digest: String,
    pub metal_view: Option<String>,  // Metal resource view descriptor
    pub coreai_view: Option<String>, // Core ML IOSurface view descriptor
    /// Per-slot IOSurface backing (None when mocked)
    pub backing_arena: Option<crate::arena::Arena>,
    /// Attestation of the real IOSurface allocation against its manifest.
    pub attestation: Option<IOSurfaceAllocationAttestation>,
}

impl LiveIOSurfaceSlot {
    /// Returns true when the slot may be acquired for the given epoch.
    pub fn is_available_for(&self, epoch: u64, _producer: ExecutionLane) -> bool {
        matches!(self.state, SlotState::Free)
            || matches!(&self.state, SlotState::Retired { epoch: e } if *e <= epoch)
    }

    /// Reserve a slot. The slot must be Free or Retired with epoch at most
    /// the caller's epoch.
    pub fn reserve(&mut self, epoch: u64, producer: ExecutionLane) -> Result<(), String> {
        match &self.state {
            SlotState::Free => {}
            SlotState::Retired { epoch: e } if *e <= epoch => {}
            _ => {
                return Err(format!(
                    "slot {} cannot be reserved from state {:?}",
                    self.manifest.slot_id, self.state
                ));
            }
        }
        self.state = SlotState::Reserved { epoch, producer };
        Ok(())
    }

    /// Transition to Writing state.
    pub fn mark_writing(&mut self, epoch: u64, producer: ExecutionLane) {
        self.state = SlotState::Writing { epoch, producer };
    }

    /// Transition to Ready state and bump slot generation.
    pub fn mark_ready(&mut self, epoch: u64, producer: ExecutionLane) {
        self.state = SlotState::Ready { epoch, producer };
        self.generation += 1;
    }

    /// Transition to Reading state. Only valid from Ready with matching epoch.
    pub fn mark_reading(&mut self, epoch: u64, consumer: ExecutionLane) -> Result<(), String> {
        match &self.state {
            SlotState::Ready {
                epoch: e,
                producer: _,
            } if *e == epoch => {}
            _ => {
                return Err(format!(
                    "slot {} not ready for reading at epoch {}",
                    self.manifest.slot_id, epoch
                ));
            }
        }
        self.state = SlotState::Reading { epoch, consumer };
        Ok(())
    }

    /// Retire the slot.
    pub fn retire(&mut self, epoch: u64) {
        self.state = SlotState::Retired { epoch };
    }

    /// Poison the slot with a failure reason.
    pub fn poison(&mut self, epoch: u64, reason: SlotFailureReason) {
        self.state = SlotState::Poisoned { epoch, reason };
    }
}

/// Live shared arena at runtime.
pub struct AppleSharedArena {
    pub arena_id: ArenaId,
    pub layout_digest: String,
    pub slots: HashMap<SlotId, LiveIOSurfaceSlot>,
    pub generation: u64,
    pub ring_depth: u8,
}

impl AppleSharedArena {
    /// Create a new empty arena.
    pub fn new(arena_id: ArenaId, ring_depth: u8) -> Self {
        Self {
            arena_id,
            layout_digest: String::new(),
            slots: HashMap::new(),
            generation: 0,
            ring_depth,
        }
    }

    /// Add a slot to the arena.
    pub fn add_slot(&mut self, slot: LiveIOSurfaceSlot) {
        let id = slot.manifest.slot_id;
        self.slots.insert(id, slot);
    }

    /// Borrow a slot by id.
    pub fn slot(&self, id: SlotId) -> Option<&LiveIOSurfaceSlot> {
        self.slots.get(&id)
    }

    /// Mutably borrow a slot by id.
    pub fn slot_mut(&mut self, id: SlotId) -> Option<&mut LiveIOSurfaceSlot> {
        self.slots.get_mut(&id)
    }

    /// Advance the arena generation counter.
    pub fn advance_generation(&mut self) {
        self.generation += 1;
    }

    /// Returns true when every slot has been retired for the given epoch.
    /// Return a pool-snapshot of slot state for lifecycle diagnostics.
    pub fn pool_snapshot(&self) -> IOSurfacePoolSnapshot {
        let total_slots = self.slots.len() as u32;
        let mut leased = 0u32;
        let mut free = 0u32;
        let mut pending_release = 0u32;

        for slot in self.slots.values() {
            match &slot.state {
                SlotState::Free => free += 1,
                SlotState::Reserved { .. }
                | SlotState::Writing { .. }
                | SlotState::Ready { .. }
                | SlotState::Reading { .. } => {
                    leased += 1;
                }
                SlotState::Retired { .. } => pending_release += 1,
                SlotState::Poisoned { .. } => {
                    // Poisoned slots are neither free nor leased.
                }
            }
        }

        IOSurfacePoolSnapshot {
            total_slots,
            leased_slots: leased,
            free_slots: free,
            pending_release_slots: pending_release,
            allocation_failures: 0, // tracked externally via counters
            release_failures: 0,
            high_watermark: total_slots.max(leased),
        }
    }

    /// Returns true when every slot has been retired for the given epoch.
    pub fn all_slots_retired(&self, epoch: u64) -> bool {
        self.slots
            .values()
            .all(|s| matches!(&s.state, SlotState::Retired { epoch: e } if *e == epoch))
    }

    /// Install an arena from its sealed manifest.
    /// Fails if any constraint cannot be satisfied exactly — no silent reshaping.
    pub fn install(
        manifest: &crate::ecs::compute_image::apple_cimage_manifest::AppleSharedArenaManifest,
    ) -> Result<Self, String> {
        if manifest.allocation_bytes == 0 {
            return Err("allocation_bytes must be > 0".into());
        }
        if manifest.slots.is_empty() {
            return Err("arena manifest has no slots".into());
        }
        let mut arena = Self::new(
            format!(
                "arena-{}",
                &manifest.arena_layout_digest[..8.min(manifest.arena_layout_digest.len())]
            ),
            manifest.ring_depth,
        );
        arena.layout_digest = manifest.arena_layout_digest.clone();

        for slot_manifest in &manifest.slots {
            let reuse_class = match slot_manifest.reuse_class.as_str() {
                "exclusive" => SlotReuseClass::Exclusive,
                "shared_readonly" => SlotReuseClass::SharedReadOnly,
                _ => SlotReuseClass::RingReuse {
                    ring_depth: manifest.ring_depth,
                },
            };
            let slot = LiveIOSurfaceSlot {
                manifest: IOSurfaceSlotManifest {
                    slot_id: slot_manifest.slot_id,
                    tensor_id: slot_manifest.tensor_id.clone(),
                    byte_offset: slot_manifest.byte_offset,
                    byte_length: slot_manifest.byte_length,
                    dtype: slot_manifest.dtype.clone(),
                    logical_shape: slot_manifest.logical_shape.clone(),
                    physical_shape: slot_manifest.physical_shape.clone(),
                    strides_bytes: slot_manifest.strides_bytes.clone(),
                    layout: slot_manifest.layout.clone(),
                    producer: slot_manifest.producer,
                    consumer: slot_manifest.consumer,
                    reuse_class,
                    required_alignment: slot_manifest.required_alignment,
                },
                state: SlotState::Free,
                generation: 0,
                layout_digest: manifest.arena_layout_digest.clone(),
                metal_view: None,
                coreai_view: None,
                backing_arena: None,
                attestation: None,
            };
            arena.add_slot(slot);
        }
        // Allocate per-slot IOSurface backing.
        for slot_entry in arena.slots.values_mut() {
            let byte_count = slot_entry.manifest.byte_length;
            if byte_count > 0 {
                let pw = slot_entry
                    .manifest
                    .physical_shape
                    .first()
                    .copied()
                    .unwrap_or(1);
                let ph = slot_entry
                    .manifest
                    .physical_shape
                    .get(1)
                    .copied()
                    .unwrap_or(1);
                // Float16 slots use dtype-aware allocator (creates CVPixelBuffer with
                // kCVPixelFormatType_OneComponent16Half). Other slots use generic surface.
                let backing = match slot_entry.manifest.dtype.as_str() {
                    "float16" | "fp16" => {
                        crate::arena::Arena::new(pw, ph, crate::arena::DataType::Float16)
                    }
                    _ => crate::arena::Arena::new_bytes(byte_count as u32),
                }
                .map_err(|e| {
                    format!(
                        "failed to allocate backing for slot {}: {}",
                        slot_entry.manifest.slot_id, e
                    )
                })?;
                slot_entry.backing_arena = Some(backing);
                // Attest the IOSurface allocation against the manifest.
                let backing = slot_entry.backing_arena.as_ref().unwrap();
                let pixel_fmt = backing.info.pixel_format as u32;
                let fp16_ok = pixel_fmt == 0x4C303068 || pixel_fmt == 0x4C303066;
                let capacity =
                    (backing.info.height as u64).saturating_mul(backing.info.bytes_per_row as u64);
                slot_entry.attestation = Some(IOSurfaceAllocationAttestation {
                    slot_id: slot_entry.manifest.slot_id,
                    iosurface_id: backing.io_surface_id() as u32,
                    actual_width: backing.info.width as u32,
                    actual_height: backing.info.height as u32,
                    actual_bytes_per_row: backing.info.bytes_per_row as u32,
                    actual_pixel_format: pixel_fmt,
                    actual_byte_capacity: capacity,
                    manifest_layout_digest: slot_entry.layout_digest.clone(),
                    attested: fp16_ok
                        && backing.info.width > 0
                        && backing.info.height > 0
                        && capacity >= slot_entry.manifest.byte_length as u64,
                });
                if !slot_entry
                    .attestation
                    .as_ref()
                    .map(|a| a.attested)
                    .unwrap_or(false)
                {
                    return Err(format!(
                        "FP16 slot {} attestation failed",
                        slot_entry.manifest.slot_id
                    ));
                }
            }
        }
        Ok(arena)
    }

    /// Build an ArenaInfo pointing to this slot within the IOSurface.
    /// Returns None if the slot has no IOSurface backing.
    pub fn arena_info_for_slot(&self, slot_id: SlotId) -> Option<crate::arena_info::ArenaInfo> {
        let slot = self.slots.get(&slot_id)?;
        let backing = slot.backing_arena.as_ref()?;
        let base = unsafe { backing.base_ptr() } as *mut u8;
        let byte_size = slot.manifest.byte_length as i32;
        let bytes_per_row = *slot.manifest.strides_bytes.first().unwrap_or(&0) as i32;
        let logical_dim0 = *slot.manifest.logical_shape.first().unwrap_or(&1) as i32;
        let logical_dim1 = *slot.manifest.logical_shape.get(1).unwrap_or(&1) as i32;
        Some(crate::arena_info::ArenaInfo {
            width: logical_dim0,
            height: logical_dim1,
            logical_dim0,
            logical_dim1,
            pixel_format: backing.info.pixel_format as i32,
            byte_size,
            bytes_per_row,
            base_address: base as *mut std::ffi::c_void,
            cv_buffer: std::ptr::null_mut(),
            io_surface: backing.info.io_surface,
        })
    }
}

/// SlotEpoch for generation tracking.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct SlotEpoch {
    pub epoch: u64,
    pub arena_generation: u64,
    pub slot_generation: u64,
}

#[cfg(test)]
mod tests {
    use super::*;

    fn make_test_slot(id: SlotId) -> LiveIOSurfaceSlot {
        LiveIOSurfaceSlot {
            manifest: IOSurfaceSlotManifest {
                slot_id: id,
                tensor_id: format!("tensor_{}", id),
                byte_offset: 0,
                byte_length: 4096,
                dtype: "float16".into(),
                logical_shape: vec![64, 64],
                physical_shape: vec![64, 64],
                strides_bytes: vec![128, 2],
                layout: "NHWC".into(),
                producer: ExecutionLane::CandleCpu,
                consumer: ExecutionLane::CoreAiAne,
                reuse_class: SlotReuseClass::Exclusive,
                required_alignment: 256,
            },
            state: SlotState::Free,
            generation: 0,
            layout_digest: "abc123".into(),
            metal_view: None,
            coreai_view: None,
            backing_arena: None,
            attestation: None,
        }
    }

    /// Full acquire → write → ready → read → retire cycle.
    #[test]
    fn test_slot_acquire_release_full_cycle() {
        let mut slot = make_test_slot(1);

        // Acquire: reserve from Free
        slot.reserve(0, ExecutionLane::CandleCpu).unwrap();
        assert!(matches!(
            slot.state,
            SlotState::Reserved {
                epoch: 0,
                producer: ExecutionLane::CandleCpu
            }
        ));

        // Write
        slot.mark_writing(0, ExecutionLane::CandleCpu);
        assert!(matches!(slot.state, SlotState::Writing { epoch: 0, .. }));

        // Ready
        slot.mark_ready(0, ExecutionLane::CandleCpu);
        assert!(matches!(slot.state, SlotState::Ready { epoch: 0, .. }));
        assert_eq!(slot.generation, 1);

        // Read (consumer)
        slot.mark_reading(0, ExecutionLane::CoreAiAne).unwrap();
        assert!(matches!(
            slot.state,
            SlotState::Reading {
                epoch: 0,
                consumer: ExecutionLane::CoreAiAne
            }
        ));

        // Retire
        slot.retire(0);
        assert!(matches!(slot.state, SlotState::Retired { epoch: 0 }));

        // Re-acquire from Retired
        slot.reserve(1, ExecutionLane::CandleCpu).unwrap();
        assert!(matches!(slot.state, SlotState::Reserved { epoch: 1, .. }));
    }

    /// Cannot reserve a slot that is in Writing (i.e. not Free/Retired).
    #[test]
    fn test_slot_writing_before_reserve_rejected() {
        let mut slot = make_test_slot(2);

        // Bypass reserve — jump straight to Writing (illegal path).
        slot.mark_writing(0, ExecutionLane::CandleCpu);
        let err = slot.reserve(1, ExecutionLane::CandleCpu).unwrap_err();
        assert!(err.contains("cannot be reserved"));
    }

    /// Ready → Reading transition enforces epoch match.
    #[test]
    fn test_slot_ready_transition_checks_epoch() {
        let mut slot = make_test_slot(3);

        slot.reserve(0, ExecutionLane::MlxGpu).unwrap();
        slot.mark_writing(0, ExecutionLane::MlxGpu);
        slot.mark_ready(0, ExecutionLane::MlxGpu);

        // Try reading with wrong epoch
        let err = slot.mark_reading(1, ExecutionLane::CoreAiAne).unwrap_err();
        assert!(err.contains("not ready for reading"));
    }

    /// Poison marks the slot and the reason survives.
    #[test]
    fn test_poison_marks_slot_and_persists_reason() {
        let mut slot = make_test_slot(4);

        slot.reserve(0, ExecutionLane::CandleCpu).unwrap();

        let reason = SlotFailureReason::MetalDispatchFailed("encoder OOM".into());
        slot.poison(0, reason.clone());

        match &slot.state {
            SlotState::Poisoned {
                epoch: 0,
                reason: r,
            } => {
                assert!(
                    matches!(r, SlotFailureReason::MetalDispatchFailed(msg) if msg == "encoder OOM")
                );
            }
            other => panic!("expected Poisoned, got {:?}", other),
        }
    }
}
