// stub — TTS migration artifact
